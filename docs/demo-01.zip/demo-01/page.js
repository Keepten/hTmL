//
// page.js
// Grundkode fuer alle Webseiten
// 

function initPage() {
	console.log( "hello world!" );
}